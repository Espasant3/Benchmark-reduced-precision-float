for (int i = 0; i < n; i++) {
    aux_vector[i] = ((float)rand() / (float)(RAND_MAX)) * 10.0;
}

for (int i = 0; i < n; i++) {
    input_vector[i] = aux_vector[i];
}