void convolve1d_generic(float* input_vector, int vector_size, WaveletKernels kernels) {
    float* low_pass_result = (float*) malloc(vector_size * sizeof(float));
    float* high_pass_result = (float*) malloc(vector_size * sizeof(float));

    for (int i = 0; i < vector_size; i++) {
        low_pass_result[i] = 0.0f;
        high_pass_result[i] = 0.0f;
    }

    for (int i = 0; i < vector_size; i++) {
        for (int j = 0; j < kernels.low_pass_size; j++) {
            if (i + j < vector_size) {
                low_pass_result[i] += input_vector[i + j] * (float)kernels.low_pass_kernel[j];
            }
        }
    }

    for (int i = 0; i < vector_size; i++) {
        for (int j = 0; j < kernels.high_pass_size; j++) {
            if (i + j < vector_size) {
                high_pass_result[i] += input_vector[i + j] * (float)kernels.high_pass_kernel[j];
            }
        }
    }

    for (int i = 0; i < vector_size / 2; i++) {
        input_vector[i] = low_pass_result[2 * i];
        input_vector[vector_size / 2 + i] = high_pass_result[2 * i];
    }

    free(low_pass_result);
    free(high_pass_result);
}