void initialize_kernels(WaveletKernels* kernels, int kernel_type) {
    switch (kernel_type) {
        case LEGALL_53_WAVELET:
            kernels->low_pass_size = 5;
            kernels->high_pass_size = 3;
            kernels->low_pass_kernel = (double*) malloc(kernels->low_pass_size * sizeof(double));
            kernels->high_pass_kernel = (double*) malloc(kernels->high_pass_size * sizeof(double));

            kernels->low_pass_kernel[0] = -1.0/8;
            kernels->low_pass_kernel[1] = 1.0/4;
            kernels->low_pass_kernel[2] = 3.0/4;
            kernels->low_pass_kernel[3] = 1.0/4;
            kernels->low_pass_kernel[4] = -1.0/8;

            kernels->high_pass_kernel[0] = -1.0/2;
            kernels->high_pass_kernel[1] = 1.0;
            kernels->high_pass_kernel[2] = -1.0/2;
            break;

        case CDF_97_WAVELET:
            kernels->low_pass_size = 9;
            kernels->high_pass_size = 7;
            kernels->low_pass_kernel = (double*) malloc(kernels->low_pass_size * sizeof(double));
            kernels->high_pass_kernel = (double*) malloc(kernels->high_pass_size * sizeof(double));

            kernels->low_pass_kernel[0] = 0.026748757411;
            kernels->low_pass_kernel[1] = -0.016864118443;
            kernels->low_pass_kernel[2] = -0.078223266529;
            kernels->low_pass_kernel[3] = 0.266864118443;
            kernels->low_pass_kernel[4] = 0.602949018236;
            kernels->low_pass_kernel[5] = 0.266864118443;
            kernels->low_pass_kernel[6] = -0.078223266529;
            kernels->low_pass_kernel[7] = -0.016864118443;
            kernels->low_pass_kernel[8] = 0.026748757411;

            kernels->high_pass_kernel[0] = 0.091271763114;
            kernels->high_pass_kernel[1] = -0.057543526229;
            kernels->high_pass_kernel[2] = -0.591271763114;
            kernels->high_pass_kernel[3] = 1.11508705;
            kernels->high_pass_kernel[4] = -0.591271763114;
            kernels->high_pass_kernel[5] = -0.057543526229;
            kernels->high_pass_kernel[6] = 0.091271763114;
            break;

        default:
            printf("Invalid kernel type\n");
            exit(EXIT_FAILURE);
    }
}