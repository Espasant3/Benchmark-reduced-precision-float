typedef struct {
    double* low_pass_kernel;
    int low_pass_size;
    double* high_pass_kernel;
    int high_pass_size;
} WaveletKernels;