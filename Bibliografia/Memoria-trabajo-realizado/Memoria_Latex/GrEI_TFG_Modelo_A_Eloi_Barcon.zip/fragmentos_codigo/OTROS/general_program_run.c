    /*
    Xestion de flags
    */

    /*
    Execución SMALL
    */

    /*
    Reserva de memoria inicial
    */


    //Para medir el tiempo de ejecución
    
    clock_t start, end;
    double cpu_time_used;

    start = clock();
    
    /* 
        Código del programa cuyo tiempo quiero medir
    */
    function(param1, param2, param3,...);

    end = clock();
    cpu_time_used = ((double) (end - start)) / CLOCKS_PER_SEC;

    printf("Tiempo de ejecucion: %f\n", cpu_time_used);

    /*
    Remate
    */