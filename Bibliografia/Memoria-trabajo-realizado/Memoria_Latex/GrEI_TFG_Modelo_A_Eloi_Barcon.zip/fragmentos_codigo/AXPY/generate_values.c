for (int i = 0; i < n; i++) {
    x[i] = ((float)rand() / (float)(RAND_MAX)) * 10.0;
    y[i] = ((float)rand() / (float)(RAND_MAX)) * 10.0;
}