// Función para calcular los valores y vectores propios de la matriz de covarianza
void calculate_eigenvalues_and_eigenvectors(Matrix* covariance, float *eigenvalues, float *eigenvectors) {
    
    int n = covariance->rows;
    int lda = n;
    int covariance_size = covariance->rows * covariance->cols;

    // Copiar datos de la matriz de covarianza a eigenvectors (array plano)
    for (int i = 0; i < covariance_size; i++) {
        eigenvectors[i] = covariance->data[i / covariance->cols][i % covariance->cols];
    }

    // Usar LAPACKE_ssyev para calcular valores y vectores propios
    int info = LAPACKE_ssyev(LAPACK_ROW_MAJOR, 'V', 'U', n, eigenvectors, lda, eigenvalues);

    if (info > 0) {
        printf("Error: LAPACKE_ssyev failed to converge. Info: %d\n", info);
        exit(EXIT_FAILURE);
    }
    
    // Ordenar valores propios y vectores propios
    sort_eigenvalues_and_eigenvectors(n, eigenvalues, eigenvectors);

}