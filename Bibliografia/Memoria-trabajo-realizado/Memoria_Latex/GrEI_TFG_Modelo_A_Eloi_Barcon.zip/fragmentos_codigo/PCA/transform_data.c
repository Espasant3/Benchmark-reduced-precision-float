// Función para transformar los datos usando los vectores propios
void transform_data(Matrix* matrix, float* eigenvectors, Matrix* transformed_data) {

    if (matrix->rows != transformed_data->rows || matrix->cols != transformed_data->cols) {
        printf("Error: Dimensiones incompatibles entre matrix y transformed_data.\n");
        _free_matrix(matrix);
        _free_matrix(transformed_data);
        free(eigenvectors);
        exit(EXIT_FAILURE);
    }

    int matrix_size = matrix->rows * matrix->cols;
    int transformed_size = transformed_data->rows * transformed_data->cols;

    // Asegurarse de que los punteros son válidos y alineados correctamente
    float* matrix_data = (float*)calloc(matrix_size, sizeof(float));
    float* transformed_data_data = (float*)calloc(transformed_size, sizeof(float));

    for (int i = 0; i < matrix_size; i++) {
        matrix_data[i] = matrix->data[i / matrix->cols][i % matrix->cols];
    }

    cblas_sgemm(CblasRowMajor, CblasNoTrans, CblasNoTrans, 
                matrix->rows, matrix->cols, matrix->cols, 
                1.0f, matrix_data, matrix->cols, 
                eigenvectors, matrix->cols, 
                0.0f, transformed_data_data, matrix->cols);

    // Copiar los datos de vuelta a transformed_data
    for (int i = 0; i < transformed_size; i++) {
        transformed_data->data[i / transformed_data->cols][i % transformed_data->cols] = transformed_data_data[i];
    }


    free(matrix_data);
    free(transformed_data_data);
}
