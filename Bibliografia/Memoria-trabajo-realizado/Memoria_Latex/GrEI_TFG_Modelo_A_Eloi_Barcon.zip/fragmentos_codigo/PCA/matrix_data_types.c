// Estructura para representar una matriz
typedef struct {
    int rows;
    int cols;
    float** data;
} Matrix;