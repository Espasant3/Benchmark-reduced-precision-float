// Función principal para realizar PCA
void do_pca(Matrix* matrix) {
    // Estandarizar la matriz
    standarize_matrix(matrix);

    // Crear matriz de covarianza
    Matrix* covariance = _create_Matrix(matrix->cols, matrix->cols);
    if (covariance == NULL) {
        printf("Error: No se pudo reservar memoria para la matriz de covarianza.\n");
        _free_matrix(matrix);
        exit(EXIT_FAILURE);
    }

    // Calcular la matriz de covarianza
    calculate_covariance(matrix, covariance);

    // Asignar memoria para eigenvalues y eigenvectors
    float* eigenvalues = (float*) calloc(covariance->rows, sizeof(float));
    float* eigenvectors = (float*) calloc(covariance->rows * covariance->cols, sizeof(float));

    if (eigenvalues == NULL || eigenvectors == NULL) {
        printf("Error: No se pudo reservar memoria para eigenvalues y eigenvectors.\n");
        _free_matrix(matrix);
        _free_matrix(covariance);
        exit(EXIT_FAILURE);
    }

    // Calcular valores propios y vectores propios
    calculate_eigenvalues_and_eigenvectors(covariance, eigenvalues, eigenvectors);

    // Crear matriz para datos transformados
    Matrix* datos_transformados = _create_Matrix(matrix->rows, matrix->cols);

    // Transformar datos usando los vectores propios
    transform_data(matrix, eigenvectors, datos_transformados);

    // Liberar memoria de eigenvalues y eigenvectors
    free(eigenvalues);
    free(eigenvectors);

    // Copiar datos transformados de vuelta a la matriz original
    _copy_matrix(datos_transformados, matrix);

    // Liberar memoria
    _free_matrix(datos_transformados);
    _free_matrix(covariance);
}