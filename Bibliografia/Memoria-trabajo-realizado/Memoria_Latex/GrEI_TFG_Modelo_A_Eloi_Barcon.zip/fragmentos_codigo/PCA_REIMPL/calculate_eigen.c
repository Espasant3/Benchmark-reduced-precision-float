// Función para calcular los valores y vectores propios de la matriz de covarianza
void calculate_eigenvalues_and_eigenvectors(Matrix* covariance, _Float16 *eigenvalues, _Float16 *eigenvectors) {
    
    int n = covariance->rows;
    int lda = n;

    // Usar LAPACKE_hfsyev para calcular valores y vectores propios
    int info = LAPACKE_hfsyev(LAPACK_ROW_MAJOR, 'V', 'U', n, eigenvectors, lda, eigenvalues);

    if (info > 0) {
        free(eigenvectors);
        free(eigenvalues);
        _free_matrix(covariance);
        printf("Error: LAPACKE_hsyev failed to converge. Info: %d\n", info);
        exit(EXIT_FAILURE);
    }

    // Ordenar valores propios y vectores propios
    sort_eigenvalues_and_eigenvectors(n, eigenvalues, eigenvectors);
}