#ifdef USE_FP16
  typedef __fp16 lapack_float;
#elif defined(USE_BF16)
  typedef __bf16 lapack_float;
#else
  // Si ninguna de las opciones se define, usamos _Float16 por defecto
  typedef _Float16 lapack_float;
#endif